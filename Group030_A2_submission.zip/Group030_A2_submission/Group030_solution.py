# Group030 A2 solution: matching notebook source.
# Executed provisionally with pasted lexicon / NLTK 3.9.1.
# Read resource limitations before submission. Set strict mode for final verification.


# %% [markdown]
# 1. Configuration, resource limitations and input integrity
# This is a complete computational workflow for Tasks 1–3, executed provisionally, not an unconditional submission-ready solution. This environment has NLTK 3.9.1, whereas the contract requires 3.9.2. The user supplied paste.txt as the extracted lexicon text; the required original ZIP is absent. No downloads or substitutions from the internet are used. Resource identity is unresolved. Provisional sentiment results must be confirmed in strict mode before submission.
# 
# Place the notebook beside the extracted original input package or configure DATA_DIR to that package. In provisional mode, PASTED_LEXICON must point to the user-supplied paste.txt outside the submission folder. In the final local run install the declared dependencies first, set STRICT_RESOURCE_CONTRACT=True and point DATA_DIR at the complete original package. Strict mode verifies every manifest file and the required NLTK version before analysis. Do not resubmit input data or the lexicon.
# 
# Sources: supplied FIT5196 S2 2026 A2 specification §§2–7, README, manifests and resource_contract. AI assistance: Perplexity generated code and explanations; the group must inspect, independently verify and declare material use. Executable checks below are evidence, not a guarantee of reference-answer equivalence.

# %%
from pathlib import Path
from decimal import Decimal
from datetime import datetime
import json, hashlib, platform, re, importlib.metadata
import numpy as np
import pandas as pd
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler, MinMaxScaler

GROUP_ID = "Group030"
DATA_DIR = Path(".")
OUTPUT_DIR = Path("output/Group030_A2_submission")
STRICT_RESOURCE_CONTRACT = False
PASTED_LEXICON = DATA_DIR / "paste.txt"
RANDOM_STATE = 5196
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
pd.set_option("display.max_columns", 25)
pd.set_option("display.width", 180)

def locate(original, uploaded):
    original_path = DATA_DIR / original
    return original_path if original_path.exists() else DATA_DIR / uploaded

paths = {"dirty":locate(f"{GROUP_ID}_dirty_data.csv","Group030_dirty_data-8.csv"),
         "missing":locate(f"{GROUP_ID}_missing_data.csv","Group030_missing_data.csv"),
         "outlier":locate(f"{GROUP_ID}_outlier_data.csv","Group030_outlier_data-2.csv")}
manifest_path=locate("A2_manifest.json","A2_manifest-7.json")
contract_path=locate("resource_contract.json","resource_contract-5.json")
warehouse_path=locate("warehouses.csv","warehouses-6.csv")
manifest=json.loads(manifest_path.read_text())
contract=json.loads(contract_path.read_text())
assert manifest["group_alias"]==GROUP_ID
raw={batch:pd.read_csv(path,dtype=str,keep_default_na=False) for batch,path in paths.items()}
warehouses=pd.read_csv(warehouse_path)
SCHEMA=["order_id","customer_id","date","nearest_warehouse","shopping_cart","order_price","delivery_charges","customer_lat","customer_long","coupon_discount","order_total","season","is_expedited_delivery","distance_to_nearest_warehouse","latest_customer_review","is_happy_customer"]
AUDIT_SCHEMA=["source_file","record_key","field_name","issue_type","original_value","corrected_value","method","evidence","confidence"]
resolved_paths={f"{GROUP_ID}_{batch}_data.csv":p for batch,p in paths.items()}
resolved_paths.update({"warehouses.csv":warehouse_path,"resource_contract.json":contract_path,
    "README.md":locate("README.md","README-4.md"),"input_manifest.csv":locate("input_manifest.csv","input_manifest-3.csv")})
integrity=[]
for entry in manifest["files"]:
    path=resolved_paths.get(entry["path"],DATA_DIR/entry["path"])
    exists=path.is_file()
    match=exists and hashlib.sha256(path.read_bytes()).hexdigest()==entry["sha256"]
    integrity.append({"file":entry["path"],"exists":exists,"checksum_match":bool(match)})
integrity=pd.DataFrame(integrity)
print("Runtime:",platform.python_version(),"NLTK:",nltk.__version__)
print(integrity.to_string(index=False))
assert integrity.loc[integrity.file.str.endswith(".csv"),"checksum_match"].all()
resource_path=DATA_DIR/contract["vader_lexicon_relative_path"]
resource_verified=resource_path.is_file() and hashlib.sha256(resource_path.read_bytes()).hexdigest()==contract["vader_lexicon_sha256"]
version_verified=nltk.__version__==contract["nltk_version"]
if STRICT_RESOURCE_CONTRACT:
    assert integrity.checksum_match.all(),"Missing/mismatched supplied resource; restore original package."
    assert version_verified,"Install NLTK version from resource_contract.json before final offline execution."
    import zipfile
    with zipfile.ZipFile(resource_path) as z:
        members=[name for name in z.namelist() if name.endswith("vader_lexicon.txt")]
    assert len(members)==1
    lexicon_uri=str(resource_path.resolve())+"/"+members[0]
else:
    assert PASTED_LEXICON.is_file(),"Provisional mode needs user-supplied paste.txt."
    lexicon_uri=str(PASTED_LEXICON.resolve())
    print("PROVISIONAL: frozen ZIP verified =",resource_verified,"required NLTK version =",version_verified)
    print("Pasted lexicon SHA256:",hashlib.sha256(PASTED_LEXICON.read_bytes()).hexdigest())
scorer=SentimentIntensityAnalyzer(lexicon_file=lexicon_uri)

# %% [markdown]
# 2. Initial EDA and protected information
# Grain: one row per order, with customers allowed to recur. Inspect each batch separately. Empty strings alone represent missing values. Keep string copies of inputs to preserve precision, identifiers, reviews and cart information. Basic distributions are diagnostic, not a reason to delete rows. No fixed anomaly percentage or ID pattern is used. Subsequent decisions use business relationships.
# 
# Confidence levels used in the audit: high = unique direct derivation supported by independent data relationships; medium = rounding-dependent/model-based reconstruction, or provisional lexicon-dependent decision; low = ambiguity/weak evidence, which is reported rather than fabricated. Confidence labels are qualitative, not probability estimates.

# %%
PROTECTED=["order_id","customer_id","shopping_cart","customer_long","coupon_discount","latest_customer_review"]
NUMERIC=["order_price","delivery_charges","customer_lat","customer_long","coupon_discount","order_total","distance_to_nearest_warehouse"]
eda=[]
for batch,df in raw.items():
    assert df.columns.tolist()==SCHEMA and len(df)==500
    assert df.order_id.is_unique and df.order_id.ne("").all()
    assert df[PROTECTED].ne("").all().all()
    eda.append({"batch":batch,"rows":len(df),"columns":len(df.columns),"customers":df.customer_id.nunique(),
                "empty_cells":int(df.eq("").sum().sum()),"affected_rows":int(df.eq("").any(axis=1).sum())})
    print("\nBATCH:",batch)
    print("Missingness:",df.eq("").sum().loc[lambda s:s>0].to_dict())
    for col in ["season","nearest_warehouse","is_expedited_delivery","is_happy_customer"]:
        print(col,df[col].value_counts(dropna=False).to_dict())
    numeric=df[NUMERIC].replace("",np.nan).astype(float)
    print(numeric.describe().round(4).to_string())
print("\n",pd.DataFrame(eda).to_string(index=False))
assert pd.concat(raw.values()).order_id.nunique()==1500
assert raw["dirty"].ne("").all().all() and raw["outlier"].ne("").all().all()
print("Interpretation: dirty warehouse aliases and positive latitudes require relationship checks; missing cells need field-specific derivation. Raw delivery extremes are not an outlier rule.")

# %% [markdown]
# 3. JSON carts and identifiable current prices
# Use json.loads, never eval. Build quantity matrix A with products as columns; each reliable observed order price is one equation A p = y. Outlier-batch carts and item prices are authoritative because only delivery_charges can be anomalous there. Fit the 500 reliable equations, require full column rank, round the inferred prices to cents, and test the 490 unused observed missing-batch equations independently. Dirty prices are excluded from fitting. Follow per-cart-entry rounding before summation. This is a current A2 price vector, not an A1 catalogue.

# %%
carts={batch:df.shopping_cart.map(json.loads) for batch,df in raw.items()}
for series in carts.values():
    for cart in series:
        assert isinstance(cart,list) and len(cart)>0
        for item in cart:
            assert isinstance(item,dict) and set(item)=={"product","quantity"}
            assert isinstance(item["product"],str) and item["product"]
            assert type(item["quantity"]) is int and item["quantity"]>0
products=sorted({item["product"] for series in carts.values() for cart in series for item in cart})
A=np.array([[sum(i["quantity"] for i in cart if i["product"]==p) for p in products] for cart in carts["outlier"]],dtype=float)
price_vector,_,rank,singular_values=np.linalg.lstsq(A,raw["outlier"].order_price.astype(float),rcond=None)
assert rank==len(products)
prices=dict(zip(products,np.round(price_vector,2)))
assert min(prices.values())>0
D=lambda value:Decimal(str(value))
def item_price(cart):
    return round(sum((round(D(prices[i["product"]])*i["quantity"],2) for i in cart),D(0)),2)
def total_price(row):
    return round(D(row["order_price"])*(1-D(row["coupon_discount"])/100)+D(row["delivery_charges"]),2)
def inverse_charge(row):
    return round(D(row["order_total"])-D(row["order_price"])*(1-D(row["coupon_discount"])/100),2)
print("Rank:",rank,"condition number:",np.linalg.cond(A))
print(pd.Series(prices,name="unit_price_AUD").to_string())
price_validation=[]
for batch in ["outlier","missing"]:
    mask=raw[batch].order_price.ne("")
    errors=(raw[batch].loc[mask,"order_price"].astype(float)-carts[batch][mask].map(lambda c:float(item_price(c)))).abs()
    price_validation.append({"batch":batch,"rows":len(errors),"max_abs_error":errors.max(),"pass":bool(errors.le(1e-8).all())})
price_validation=pd.DataFrame(price_validation)
print(price_validation.to_string(index=False))
assert price_validation["pass"].all()

# %% [markdown]
# 4. Business-rule helpers, sentiment and initial diagnosis
# Parse slash dates day-first unless year-first, and explicitly parse month-name representations observed in the dirty batch. Calendar parsing alone is not grounds to change a valid season without checking the one-field guarantee. Calculate nearest great-circle distance using the supplied warehouses and R=6371 km. A positive latitude is tested by flipping its sign and independently checking the original stored nearest warehouse and distance before any repair.
# 
# Score supplied review text unchanged. Exact sentinel No review submitted is True; otherwise use compound >=0.05. Provisional lexicon scoring is compared against all observed correct missing/outlier happiness labels. Agreement is supporting evidence only; it does not substitute for the unresolved frozen-resource/version checks.

# %%
SEASONS={12:"Summer",1:"Summer",2:"Summer",3:"Autumn",4:"Autumn",5:"Autumn",6:"Winter",7:"Winter",8:"Winter",9:"Spring",10:"Spring",11:"Spring"}
def parse_date(value):
    formats=(["%Y/%m/%d"] if "/" in value and len(value.split("/")[0])==4 else ["%d/%m/%Y"] if "/" in value else ["%Y-%m-%d","%b %d, %Y","%B %d, %Y"])
    for fmt in formats:
        try:return datetime.strptime(value,fmt)
        except ValueError:pass
    raise ValueError("Unresolved date: "+value)
def geographic(df):
    la=np.radians(df.customer_lat.astype(float).to_numpy())[:,None]
    lo=np.radians(df.customer_long.astype(float).to_numpy())[:,None]
    wl=np.radians(warehouses.latitude.to_numpy())[None,:]
    wo=np.radians(warehouses.longitude.to_numpy())[None,:]
    a=np.sin((wl-la)/2)**2+np.cos(la)*np.cos(wl)*np.sin((wo-lo)/2)**2
    distances=2*6371*np.arcsin(np.sqrt(np.clip(a,0,1)))
    return warehouses.warehouse.to_numpy()[distances.argmin(axis=1)],distances.min(axis=1)
reviews=pd.concat([df.latest_customer_review for df in raw.values()]).unique()
compound={t:(np.nan if t=="No review submitted" else scorer.polarity_scores(t)["compound"]) for t in reviews}
happiness={t:(True if t=="No review submitted" else compound[t]>=contract["compound_threshold"]) for t in reviews}
sentiment_checks=[]
for batch,df in raw.items():
    observed=df.is_happy_customer.ne("")
    expected=df.latest_customer_review.map(happiness).astype(str)
    count=int(expected[observed].ne(df.loc[observed,"is_happy_customer"]).sum())
    sentiment_checks.append({"batch":batch,"observed_labels":int(observed.sum()),"disagreements":count})
print(pd.DataFrame(sentiment_checks).to_string(index=False))
assert all(r["disagreements"]==0 for r in sentiment_checks if r["batch"]!="dirty")

def diagnosis(df):
    nw,dist=geographic(df)
    return pd.DataFrame({"date_format":df.date.map(lambda x:parse_date(x).strftime("%Y-%m-%d")).ne(df.date),
        "season":df.date.map(lambda x:SEASONS[parse_date(x).month]).ne(df.season),
        "warehouse":nw!=df.nearest_warehouse,
        "distance":abs(dist-df.distance_to_nearest_warehouse.astype(float))>0.000100001,
        "latitude":~df.customer_lat.astype(float).between(-39,-37),
        "item_price":abs(df.shopping_cart.map(json.loads).map(lambda c:float(item_price(c)))-df.order_price.astype(float))>0.010000001,
        "total":df.apply(lambda r:abs(float(total_price(r))-float(r.order_total))>0.010000001,axis=1),
        "happiness":df.latest_customer_review.map(happiness).astype(str).ne(df.is_happy_customer)},index=df.index)
initial_diagnosis=diagnosis(raw["dirty"])
print(initial_diagnosis.sum().to_string())
print(initial_diagnosis.apply(lambda r:",".join(r.index[r]) or "no initial failure",axis=1).value_counts().to_string())

# %% [markdown]
# 5. Seasonal models: reliable training and held-out evaluation
# Fit a separate intercept-plus-linear-predictors model for each season: charge = intercept + b_distance × distance + b_expedited × expedited + b_happy × happy. Boolean encoding is 0/1.
# 
# Use only originally observed complete values of the target and these predictors from the missing batch, whose observed cells are guaranteed correct. This excludes all dirty rows, outlier rows and imputed training fields. It avoids circular outlier training. Rows missing an unrelated field such as order_price remain eligible. Split each season 75/25 with random_state=5196 and report true held-out metrics. Retain those evaluation models to check the held-out residuals; refit deployment models on the eligible data only after evaluation.
# 
# Decision thresholds are five times the maximum held-out absolute residual per season, with a 0.01 AUD numerical floor. This conservative multiple is selected from independent clean-error evidence, not from marking tolerances or a chosen deletion percentage. Test sensitivity to factors 3 and 10. Strong fit alone does not prove repair correctness: subsequent independent arithmetic, geographical, sentiment and preservation checks are also required.

# %%
FEATURES=["distance_to_nearest_warehouse","is_expedited_delivery","is_happy_customer"]
def design(df):
    values=np.column_stack([df[FEATURES[0]].astype(float),df[FEATURES[1]].map({"True":1,"False":0}),df[FEATURES[2]].map({"True":1,"False":0})]).astype(float)
    assert np.isfinite(values).all()
    return values
eligible=raw["missing"][["season","delivery_charges"]+FEATURES].ne("").all(axis=1)
models={};evaluation_models={};heldout_errors={};splits={};model_metrics=[];model_coefficients=[]
for season,g in raw["missing"][eligible].groupby("season"):
    train_idx,test_idx=train_test_split(g.index,test_size=0.25,random_state=RANDOM_STATE)
    assert not set(train_idx)&set(test_idx)
    train=raw["missing"].loc[train_idx];test=raw["missing"].loc[test_idx]
    fitted=LinearRegression().fit(design(train),train.delivery_charges.astype(float))
    predicted=fitted.predict(design(test));actual=test.delivery_charges.astype(float).to_numpy()
    errors=np.abs(actual-predicted)
    model_metrics.append({"season":season,"eligible":len(g),"train":len(train),"test":len(test),"heldout_R2":r2_score(actual,predicted),"heldout_MAE_AUD":mean_absolute_error(actual,predicted),"heldout_max_abs_AUD":errors.max()})
    evaluation_models[season]=fitted;heldout_errors[season]=errors;splits[season]=(train_idx,test_idx)
    deployment=LinearRegression().fit(design(g),g.delivery_charges.astype(float))
    models[season]=deployment
    model_coefficients.append(dict(zip(["season","intercept","distance","expedited","happy"],[season,deployment.intercept_,*deployment.coef_])))
model_metrics=pd.DataFrame(model_metrics);model_coefficients=pd.DataFrame(model_coefficients)
thresholds={s:max(0.01,5*e.max()) for s,e in heldout_errors.items()}
print(model_metrics.to_string(index=False));print(model_coefficients.to_string(index=False))
print("Thresholds, AUD:",thresholds)
assert model_metrics.heldout_R2.ge(.99).all()
def predict(df):
    result=pd.Series(index=df.index,dtype=float)
    for season,g in df.groupby("season"):
        result.loc[g.index]=models[season].predict(design(g))
    return result

# %% [markdown]
# 6. Missing batch: field-specific recovery and audit
# Recover all eight affected fields by their published relationships. Prefer inverse arithmetic to modelling missing delivery charges when the other monetary values are observed. There is exactly one missing field per affected row in these inputs, verified below, so these inverse calculations do not chain uncertain missing monetary values.
# 
# For missing expedited delivery, compare the seasonal prediction under both 0 and 1. Require one candidate to fall inside the clean residual threshold and the other outside it; record both errors. Missing happiness is review-derived, not inferred from delivery or copied from other customers. Preserve every originally observed value. Monetary inverse rounding may create a discrepancy of about one cent; do not overwrite a valid observed total to force agreement.

# %%
clean={k:df.copy(deep=True) for k,df in raw.items()}
audit_records=[]
def change(batch,index,field,new,method,evidence,confidence="high"):
    old=clean[batch].at[index,field];new=str(new)
    if old==new:return
    if batch=="missing":assert raw[batch].at[index,field]==""
    if batch=="dirty":
        assert not any(r["source_file"]==f"{GROUP_ID}_dirty_data.csv" and r["record_key"]==clean[batch].at[index,"order_id"] for r in audit_records),"Multiple-field dirty repair needs investigation"
    clean[batch].at[index,field]=new
    audit_records.append({"source_file":f"{GROUP_ID}_{batch}_data.csv","record_key":clean[batch].at[index,"order_id"],"field_name":field,"issue_type":"missing" if batch=="missing" else "dirty","original_value":"<MISSING>" if old=="" else old,"corrected_value":new,"method":method,"evidence":evidence,"confidence":confidence})
assert raw["missing"].eq("").sum(axis=1).le(1).all()
nw,dist=geographic(raw["missing"])
for i,row in raw["missing"].iterrows():
    if row.nearest_warehouse=="":change("missing",i,"nearest_warehouse",nw[i],"Minimum haversine distance; Earth radius 6371 km","S4 geographical calculation")
    if row.distance_to_nearest_warehouse=="":change("missing",i,"distance_to_nearest_warehouse",f"{dist[i]:.4f}","Minimum haversine distance; 4 decimals","S4 geographical calculation")
    if row.season=="":change("missing",i,"season",SEASONS[parse_date(row.date).month],"Australian calendar month-to-season rule","S4 calendar rule")
    if row.order_price=="":change("missing",i,"order_price",f"{item_price(json.loads(row.shopping_cart)):.2f}","Validated current cart price equations","S3 full-rank prices and independent 490-equation test")
    if row.order_total=="":change("missing",i,"order_total",f"{total_price(row):.2f}","Round item price after coupon plus delivery, no subtotal rounding","S3 published total equation")
    if row.delivery_charges=="":change("missing",i,"delivery_charges",f"{inverse_charge(row):.2f}","Invert observed order-total relationship","S3 arithmetic; inverse rounding uncertainty about 0.01 AUD","medium")
    if row.is_happy_customer=="":change("missing",i,"is_happy_customer",happiness[row.latest_customer_review],"VADER compound >=0.05; exact sentinel True","S4 compound="+str(compound[row.latest_customer_review])+"; resource verification "+str(resource_verified and version_verified),"high" if resource_verified and version_verified else "medium")
for i in raw["missing"].index[raw["missing"].is_expedited_delivery.eq("")]:
    row=clean["missing"].loc[[i]].copy();errors=[]
    for candidate in [False,True]:
        row.loc[i,"is_expedited_delivery"]=str(candidate)
        errors.append(abs(float(row.loc[i,"delivery_charges"])-float(predict(row).iloc[0])))
    best=int(np.argmin(errors));threshold=thresholds[row.loc[i,"season"]]
    assert errors[best]<=threshold and errors[1-best]>threshold
    change("missing",i,"is_expedited_delivery",bool(best),"Compare both boolean candidates against seasonal model",f"S5 errors False/True={errors}; threshold={threshold}","medium")
print("Missing changes by field:",pd.DataFrame(audit_records).field_name.value_counts().to_dict())
assert clean["missing"].ne("").all().all()

# %% [markdown]
# 7. Dirty batch: independent evidence, one affected field
# Repair direct evidence first, without overwriting downstream fields. Sign-flipped positive latitudes must explain the original stored nearest warehouse and distance; otherwise stop. Cart-based price repairs must also restore agreement with the independently observed total. Incorrect warehouse values and distances are independently recalculated only on rows not already repaired. Dirty happiness uses the unchanged review and the one-field guarantee. Normalise non-ISO date representations explicitly.
# 
# After those repairs, evaluate delivery residuals and total arithmetic together: (a) correct charge prediction plus bad total identifies order_total; (b) large residual with correct total and a well-fitting alternate boolean identifies expedited delivery; (c) large residual and bad total, with inverse charge matching the seasonal model, identifies delivery_charges. This distinguishes cause from dependent symptoms. A corrupted order_price can fail both price and total checks but only order_price is changed. A corrupted latitude can fail location, warehouse and distance checks but only latitude is changed. Never change valid totals after a model estimate.
# 
# Alternatives rejected: raw delivery IQR deletion ignores predictors; global mean imputation ignores exact relationships; fitting on contaminated dirty/outlier targets can bias repairs; row-specific hard-coded patches are not used.

# %%
def dirty_changed(i):
    oid=clean["dirty"].at[i,"order_id"]
    return any(r["source_file"]==f"{GROUP_ID}_dirty_data.csv" and r["record_key"]==oid for r in audit_records)
for i,row in raw["dirty"].iterrows():
    if float(row.customer_lat)>0:
        candidate=raw["dirty"].loc[[i]].copy()
        candidate.at[i,"customer_lat"]=str(-D(row.customer_lat))
        cand_nw,cand_dist=geographic(candidate)
        assert cand_nw[0]==row.nearest_warehouse and abs(cand_dist[0]-float(row.distance_to_nearest_warehouse))<=0.000100001
        change("dirty",i,"customer_lat",candidate.at[i,"customer_lat"],"Latitude-sign correction verified by original warehouse and distance",f"S7 candidate nearest={cand_nw[0]}; distance={cand_dist[0]:.8f}")
        continue
    formatted=parse_date(row.date).strftime("%Y-%m-%d")
    if formatted!=row.date:
        assert SEASONS[parse_date(row.date).month]==row.season
        change("dirty",i,"date",formatted,"Explicit calendar parsing; slash day-first unless year-first","S4/S7 calendar representation")
        continue
    expected_season=SEASONS[parse_date(row.date).month]
    if row.season!=expected_season:
        change("dirty",i,"season",expected_season,"Australian calendar month-to-season rule","S4/S7 date is valid and row has at most one incorrect field")
        continue
    expected_price=item_price(json.loads(row.shopping_cart))
    if abs(float(expected_price)-float(row.order_price))>0.010000001:
        candidate=row.copy();candidate.order_price=str(expected_price)
        assert abs(float(total_price(candidate))-float(row.order_total))<=0.010000001
        change("dirty",i,"order_price",f"{expected_price:.2f}","Current prices and original error-free shopping cart","S3/S7 cart repair also restores original total")
        continue
    expected_happiness=str(happiness[row.latest_customer_review])
    if row.is_happy_customer!=expected_happiness:
        change("dirty",i,"is_happy_customer",expected_happiness,"Original-review VADER rule; exact sentinel True",f"S4 compound={compound[row.latest_customer_review]}; strict resource checks={resource_verified and version_verified}","high" if resource_verified and version_verified else "medium")
        continue
    expected_nw,expected_dist=geographic(raw["dirty"].loc[[i]])
    if row.nearest_warehouse!=expected_nw[0]:
        assert abs(float(row.distance_to_nearest_warehouse)-expected_dist[0])<=0.000100001
        change("dirty",i,"nearest_warehouse",expected_nw[0],"Nearest supplied warehouse by minimum haversine distance","S4/S7 correct coordinate and original distance corroboration")
        continue
    if abs(float(row.distance_to_nearest_warehouse)-expected_dist[0])>0.000100001:
        change("dirty",i,"distance_to_nearest_warehouse",f"{expected_dist[0]:.4f}","Recalculate haversine nearest distance; R=6371 km","S4/S7 original coordinates and nearest warehouse agree")
for i,row in clean["dirty"].copy().iterrows():
    residual=float(row.delivery_charges)-float(predict(clean["dirty"].loc[[i]]).iloc[0])
    limit=thresholds[row.season]
    arithmetic_error=abs(float(total_price(row))-float(row.order_total))
    if dirty_changed(i):
        assert abs(residual)<=limit and arithmetic_error<=0.010000001
        continue
    if abs(residual)>limit:
        if arithmetic_error<=0.010000001:
            candidate=clean["dirty"].loc[[i]].copy()
            candidate.at[i,"is_expedited_delivery"]=str(row.is_expedited_delivery!="True")
            alternate_error=abs(float(row.delivery_charges)-float(predict(candidate).iloc[0]))
            assert alternate_error<=limit
            change("dirty",i,"is_expedited_delivery",candidate.at[i,"is_expedited_delivery"],"Alternate boolean uniquely restores seasonal fit; original arithmetic valid",f"S5/S7 original residual={residual}; alternate abs residual={alternate_error}; threshold={limit}","medium")
        else:
            corrected=inverse_charge(row)
            expected=float(predict(clean["dirty"].loc[[i]]).iloc[0])
            assert abs(float(corrected)-expected)<=limit
            change("dirty",i,"delivery_charges",f"{corrected:.2f}","Inverse original-total arithmetic corroborated by seasonal model",f"S3/S5/S7 inverse={corrected}; predicted={expected}; threshold={limit}; observed total preserved","medium")
    elif arithmetic_error>0.010000001:
        change("dirty",i,"order_total",f"{total_price(row):.2f}","Published arithmetic; current item price and seasonal charge independently valid",f"S3/S5/S7 charge residual={residual}")
dirty_audit=pd.DataFrame([r for r in audit_records if r["issue_type"]=="dirty"])
print(dirty_audit.field_name.value_counts().to_string())
print("Changed dirty rows:",dirty_audit.record_key.nunique(),"unchanged:",500-dirty_audit.record_key.nunique())
assert dirty_audit.record_key.is_unique
print("Post-repair initial-rule failures:",diagnosis(clean["dirty"]).sum().to_dict())

# %% [markdown]
# 8. Outlier batch: conditional residuals and row removal
# Apply the seasonal deployment models fitted exclusively on correct observed missing-batch data. An outlier is an order whose absolute conditional delivery-charge residual exceeds its season's independently calibrated threshold. Remove the whole row and log delivery_charges with issue_type=outlier_row and corrected_value=ROW_REMOVED. Do not repair delivery charges or totals in this batch.
# 
# Report residual quantiles, retained/removed ranges and sensitivity to threshold factors 3, 5 and 10. The threshold is not the 0.08 AUD marking tolerance. Expensive valid orders remain if their predictors explain the cost, while moderate raw charges can be removed if inconsistent with their expected charge. Charge ranges and residual separation below show actual evidence.

# %%
outlier_residual=raw["outlier"].delivery_charges.astype(float)-predict(raw["outlier"])
limits=raw["outlier"].season.map(thresholds)
remove=outlier_residual.abs()>limits
removed_ids=set(raw["outlier"].loc[remove,"order_id"])
print("Absolute residual quantiles:",outlier_residual.abs().quantile([0,.25,.5,.75,.9,.95,.96,.99,1]).to_dict())
sensitivity=[]
for factor in [3,5,10]:
    cut=raw["outlier"].season.map({s:max(.01,factor*e.max()) for s,e in heldout_errors.items()})
    ids=set(raw["outlier"].loc[outlier_residual.abs()>cut,"order_id"])
    sensitivity.append({"factor":factor,"removed":len(ids),"same_ID_set_as_selected":ids==removed_ids})
print(pd.DataFrame(sensitivity).to_string(index=False))
for label,mask in [("retained",~remove),("removed",remove)]:
    charges=raw["outlier"].loc[mask,"delivery_charges"].astype(float)
    residuals=outlier_residual[mask].abs()
    print(label,"rows",int(mask.sum()),"charge range",(charges.min(),charges.max()),"abs residual range",(residuals.min(),residuals.max()))
for i,row in raw["outlier"].loc[remove].iterrows():
    audit_records.append({"source_file":f"{GROUP_ID}_outlier_data.csv","record_key":row.order_id,"field_name":"delivery_charges","issue_type":"outlier_row","original_value":row.delivery_charges,"corrected_value":"ROW_REMOVED","method":"Remove row using conditional seasonal charge residual", "evidence":f"S5/S8 season={row.season}; residual={outlier_residual[i]:.8f}; threshold={limits[i]:.8f}","confidence":"high"})
clean["outlier"]=raw["outlier"].loc[~remove].copy()
audit=pd.DataFrame(audit_records,columns=AUDIT_SCHEMA)
print("Output batch rows:",{k:len(v) for k,v in clean.items()})
print("Audit counts:",audit.issue_type.value_counts().to_dict())

# %% [markdown]
# 9. Task 2: write, re-read and execute validation checks
# Write only the original 16-column schema, identifiers as strings, UTF-8 and no pandas index. Re-read actual deliverables before validation. Preserve every observed cell in the missing batch, every retained outlier cell and all protected fields. Dirty changes are limited to the audited one-field decisions, with unchanged-row preservation explicitly checked. We cannot independently know every reference value; preservation plus multiple independent relationships is stronger evidence than any one consistency test alone.
# 
# Validation comparisons use absolute tolerances with no relative tolerance. Strict cent-level total equality is reported separately from <=0.01 AUD inverse-rounding allowance. Small inverse rounding discrepancies are explained rather than patched. Reconstructed coordinates retain original precision and distances four decimal places. Validation results include observed counts, status and interpretation, and record resource checks as unresolved when applicable.

# %%
output_paths={batch:OUTPUT_DIR/f"{GROUP_ID}_{batch}_clean.csv" for batch in clean}
for batch,df in clean.items():df.to_csv(output_paths[batch],index=False,encoding="utf-8")
audit_path=OUTPUT_DIR/"audit_log.csv"
audit.to_csv(audit_path,index=False,encoding="utf-8")
submitted={batch:pd.read_csv(path,dtype=str,keep_default_na=False) for batch,path in output_paths.items()}
submitted_audit=pd.read_csv(audit_path,dtype=str,keep_default_na=False)
validation=[]
def check(check_id,passed,observed,interpretation):
    validation.append({"check":check_id,"status":"PASS" if passed else "UNRESOLVED","observed":str(observed),"interpretation":interpretation})
check("V01_frozen_lexicon",resource_verified,resource_verified,"Restore and verify original frozen ZIP in strict final run; pasted text is provisional only.")
check("V02_NLTK_version",version_verified,nltk.__version__,"Required NLTK "+contract["nltk_version"]+"; rerun with declared dependencies.")
all_changed=set();logged_changed=set()
for batch,df in submitted.items():
    original=raw[batch].set_index("order_id");indexed=df.set_index("order_id")
    check(batch+"_schema",df.columns.tolist()==SCHEMA,df.columns.tolist(),"Original schema and column order; no index/audit columns.")
    check(batch+"_complete",df.ne("").all().all(),int(df.eq("").sum().sum()),"All required fields nonempty.")
    correct_ids=(set(df.order_id)==set(raw[batch].order_id) if batch!="outlier" else set(df.order_id)|removed_ids==set(raw[batch].order_id) and not set(df.order_id)&removed_ids)
    check(batch+"_IDs",df.order_id.is_unique and correct_ids and (len(df)==500 if batch!="outlier" else len(df)+len(removed_ids)==500),f"retained={len(df)}; removed={len(removed_ids) if batch=='outlier' else 0}","No unexpected/duplicate IDs; complete dirty/missing sets; retained/removed reconciliation.")
    num=df[NUMERIC].apply(pd.to_numeric,errors="coerce")
    check(batch+"_numeric",np.isfinite(num.to_numpy()).all(),num.isna().sum().to_dict(),"All numeric values parseable and finite.")
    check(batch+"_booleans",all(df[c].isin(["True","False"]).all() for c in FEATURES[1:]),{c:df[c].unique().tolist() for c in FEATURES[1:]},"Consistent boolean encoding.")
    check(batch+"_dates",df.date.str.fullmatch(r"\d{4}-\d{2}-\d{2}").all() and all(parse_date(x).strftime("%Y-%m-%d")==x for x in df.date),len(df),"Valid ISO calendar dates.")
    expected_season=df.date.map(lambda x:SEASONS[parse_date(x).month])
    check(batch+"_season",expected_season.eq(df.season).all(),int(expected_season.ne(df.season).sum()),"Australian calendar month relationship.")
    nw,ds=geographic(df)
    geoerr=abs(ds-df.distance_to_nearest_warehouse.astype(float))
    check(batch+"_geography",(nw==df.nearest_warehouse).all() and geoerr.le(.000100001).all() and num.customer_lat.between(-39,-37).all() and num.customer_long.between(144,146).all(),f"warehouse mismatches={int((nw!=df.nearest_warehouse).sum())}; max distance error={geoerr.max():.9f}","Warehouse reference plus haversine R=6371 km; broad Melbourne-consistent coordinate bounds.")
    cartvalid=True
    for cart in df.shopping_cart.map(json.loads):
        cartvalid=cartvalid and isinstance(cart,list) and len(cart)>0 and all(set(i)=={"product","quantity"} and i["product"] in prices and type(i["quantity"]) is int and i["quantity"]>0 for i in cart)
    priceerr=abs(df.shopping_cart.map(json.loads).map(lambda c:float(item_price(c)))-num.order_price)
    check(batch+"_carts_prices",cartvalid and priceerr.le(.010000001).all(),f"max price error={priceerr.max():.9f}","Valid JSON structure, preserved products/quantities and validated prices.")
    h=df.latest_customer_review.map(happiness).astype(str)
    check(batch+"_happiness",h.eq(df.is_happy_customer).all(),int(h.ne(df.is_happy_customer).sum()),"Conditional on supplied lexicon text/runtime; strict resource checks remain separate.")
    totalerr=abs(df.apply(lambda r:float(total_price(r)),axis=1)-num.order_total)
    check(batch+"_arithmetic",totalerr.le(.010000001).all(),f"max absolute error={totalerr.max():.9f}; nonzero at >1e-8={int(totalerr.gt(1e-8).sum())}","Coupon only discounts items; <=0.01 allowance for inverse rounding, observed totals preserved.")
    check(batch+"_numeric_domains",num.coupon_discount.between(0,100).all() and num[["order_price","order_total","delivery_charges","distance_to_nearest_warehouse"]].ge(0).all().all(),num.min().to_dict(),"Nonnegative values and percentage domain.")
    residual=num.delivery_charges-predict(df)
    check(batch+"_seasonal_residual",residual.abs().le(df.season.map(thresholds)).all(),f"max absolute residual={residual.abs().max():.9f}","Retained orders agree with independently calibrated seasonal relationship.")
    protected_equal=all(indexed[c].eq(original.loc[indexed.index,c]).all() for c in PROTECTED if c!="order_id")
    check(batch+"_protected",protected_equal,len(PROTECTED),"Error-free identifiers/cart/longitude/coupon/review information preserved exactly.")
    before=original.loc[indexed.index,SCHEMA[1:]];after=indexed[SCHEMA[1:]]
    differences=before.ne(after)
    for oid,field in differences.stack().loc[lambda s:s].index:all_changed.add((f"{GROUP_ID}_{batch}_data.csv",oid,field))
    if batch=="missing":
        preserved=((before==after)|before.eq("")).all().all()
        check("missing_observed_preservation",preserved,int((differences&before.ne("")).sum().sum()),"No originally observed missing-batch cells changed.")
    if batch=="outlier":check("outlier_retained_preservation",not differences.any().any(),int(differences.sum().sum()),"All retained rows unchanged; only removal is permitted.")
    if batch=="dirty":
        edited_ids=set(dirty_audit.record_key)
        untouched=before.loc[~before.index.isin(edited_ids)].equals(after.loc[~after.index.isin(edited_ids)])
        check("dirty_one_field_preservation",differences.sum(axis=1).le(1).all() and untouched,f"changed rows={int(differences.any(axis=1).sum())}; untouched rows={len(before)-len(edited_ids)}","Only audited fields changed; no multi-field cascade.")
check("audit_schema",submitted_audit.columns.tolist()==AUDIT_SCHEMA,submitted_audit.columns.tolist(),"Exact audit schema and column order.")
for _,r in submitted_audit.iterrows():
    if r.issue_type!="outlier_row":
        batch=r.issue_type if r.issue_type=="dirty" else "missing"
        old=raw[batch].set_index("order_id").at[r.record_key,r.field_name]
        new=submitted[batch].set_index("order_id").at[r.record_key,r.field_name]
        assert r.original_value==("<MISSING>" if old=="" else old) and r.corrected_value==new
        logged_changed.add((r.source_file,r.record_key,r.field_name))
    else:
        assert r.original_value==raw["outlier"].set_index("order_id").at[r.record_key,"delivery_charges"]
        assert r.corrected_value=="ROW_REMOVED" and r.field_name=="delivery_charges"
check("audit_field_diff_reconciliation",all_changed==logged_changed and len(logged_changed)==int(submitted_audit.issue_type.ne("outlier_row").sum()),f"actual field changes={len(all_changed)}; logged field changes={len(logged_changed)}","One actual changed field per non-removal audit entry; replacements/originals verified.")
removal_log=submitted_audit[submitted_audit.issue_type.eq("outlier_row")]
check("audit_removal_reconciliation",set(removal_log.record_key)==removed_ids and removal_log.record_key.is_unique,len(removal_log),"One matching removal audit entry per removed outlier ID.")
check("audit_metadata",submitted_audit.confidence.isin(["high","medium","low"]).all() and submitted_audit[["method","evidence"]].ne("").all().all(),submitted_audit.confidence.value_counts().to_dict(),"Confidence defined and identifiable methods/evidence supplied.")
validation=pd.DataFrame(validation)
print(validation.to_string(index=False))
assert validation.loc[~validation.check.isin(["V01_frozen_lexicon","V02_NLTK_version"]),"status"].eq("PASS").all()
retained_fit=[]
for batch,df in submitted.items():
    for season,g in df.groupby("season"):
        actual=g.delivery_charges.astype(float);pred=predict(g)
        retained_fit.append({"batch":batch,"season":season,"n":len(g),"R2_diagnostic_not_heldout":r2_score(actual,pred),"MAE_AUD":mean_absolute_error(actual,pred),"max_abs_residual":abs(actual-pred).max()})
print("\nRetained fit diagnostics (NOT additional held-out evaluation):")
print(pd.DataFrame(retained_fit).to_string(index=False))

# %% [markdown]
# 10. Task 3: retained-sample customer profiles and baseline
# Read the actual three cleaned CSVs (not pre-write working tables), keep source_batch identity in the analysis copy and concatenate retained orders only. Removed outliers are not restored and A1 is not included. Aggregate one row per customer_id. Select order_count (activity), mean_order_value (spending per retained order) and mean_delivery_distance (delivery geography). This avoids the exact dependence total_paid = order_count × mean_order_value; correlations still require examination.
# 
# Mean order value includes delivery after item discount; it is not profit or merchandise-only revenue. Profiles describe the retained A2 sample, not full histories or lifetime value. Removing outliers may change a customer's sample count and means; acknowledge this selection effect. Numeric results remain conditional on provisional sentiment/resource handling. No clustering model, inferred number of clusters or claim of meaningful clusters is required.

# %%
analysis_batches=[]
for batch,path in output_paths.items():
    df=pd.read_csv(path,dtype={"order_id":str,"customer_id":str})
    df["source_batch"]=batch
    analysis_batches.append(df)
orders=pd.concat(analysis_batches,ignore_index=True)
assert orders.order_id.is_unique
profiles=orders.groupby("customer_id").agg(order_count=("order_id","nunique"),mean_order_value=("order_total","mean"),mean_delivery_distance=("distance_to_nearest_warehouse","mean"))
ATTRIBUTES=["order_count","mean_order_value","mean_delivery_distance"]
assert profiles.index.is_unique and profiles.notna().all().all()
assert profiles.order_count.sum()==len(orders)
print("Cleaned input rows:",orders.source_batch.value_counts().to_dict())
print("Combined distinct orders:",orders.order_id.nunique(),"Customers:",len(profiles))
print("Customer attribute summary:")
baseline_summary=profiles.describe(percentiles=[.05,.25,.5,.75,.95]).T
baseline_summary["skewness"]=profiles.skew()
print(baseline_summary.to_string())
print("Correlations:");print(profiles.corr().to_string())
print("Customer order-count distribution:",profiles.order_count.value_counts().sort_index().to_dict())

# %% [markdown]
# 11. Task 3: required scaling and nonlinear comparisons
# Keep an untransformed baseline. Fit z-score and min-max transformations to all three selected attributes for descriptive exploration of this entire retained sample; there is no held-out predictive model here, so a train-only transformer is not needed. Z-score uses population standard deviation (ddof=0), and min-max uses observed minima/maxima. IDs are never transformed. Check constants and log1p domain explicitly.
# 
# Compare log1p(mean_order_value) with its original values, then standardise the transformed three-attribute copy. In this combined treatment the order is nonlinear transformation first, scaling second. Log1p requires x > -1 and handles zero; all observed mean order values are positive. Quantile tables and skewness show actual nonlinear effects. The goal is interpretable distance-based comparison, not universal normality or improved delivery-model R-squared.
# 
# Average squared pairwise-distance contribution shares are proportional to each attribute's population variance; compute the shares explicitly. They quantify dominance from units/scales. Also compare distributions of pairwise Euclidean distances and nearest-neighbour changes across representations; different neighbours demonstrate sensitivity, not better or meaningful clusters. Min-max depends strongly on observed extremes; z-score equalises variance but retains extreme observations; log1p compresses absolute upper-tail gaps and changes comparisons toward proportional spending differences.

# %%
from scipy.spatial.distance import pdist, squareform
assert (profiles.nunique()>1).all(),"Constant features need explicit exclusion or documented zero contribution."
assert profiles.mean_order_value.gt(-1).all()
representations={"original":profiles.copy()}
scalers={}
for label,transformer in [("z_score",StandardScaler()),("min_max",MinMaxScaler())]:
    representations[label]=pd.DataFrame(transformer.fit_transform(profiles),index=profiles.index,columns=ATTRIBUTES)
    scalers[label]=transformer
nonlinear=profiles.copy()
nonlinear["mean_order_value"]=np.log1p(nonlinear.mean_order_value)
log_scaler=StandardScaler()
representations["log1p_value_then_z"]=pd.DataFrame(log_scaler.fit_transform(nonlinear),index=profiles.index,columns=ATTRIBUTES)
comparison=[];contributions=[];distance_vectors={};nearest_neighbours={}
for label,df in representations.items():
    for col in ATTRIBUTES:
        s=df[col]
        comparison.append({"representation":label,"attribute":col,"min":s.min(),"mean":s.mean(),"sd_population":s.std(ddof=0),"median":s.median(),"max":s.max(),"skewness":s.skew()})
    variances=df.var(ddof=0)
    contributions.append({"representation":label,**(variances/variances.sum()*100).to_dict()})
    vector=pdist(df.to_numpy(),metric="euclidean")
    distance_vectors[label]=vector
    matrix=squareform(vector);np.fill_diagonal(matrix,np.inf)
    nearest_neighbours[label]=matrix.argmin(axis=1)
print("All-feature scaling comparisons (S11-A):")
print(pd.DataFrame(comparison).to_string(index=False))
print("Average squared pairwise distance contribution %, S11-B:")
contributions=pd.DataFrame(contributions)
print(contributions.to_string(index=False))
nonlinear_summary=pd.DataFrame({"original_AUD":profiles.mean_order_value.quantile([0,.05,.25,.5,.75,.95,1]),"log1p_value":np.log1p(profiles.mean_order_value).quantile([0,.05,.25,.5,.75,.95,1])})
print("Nonlinear quantile effect S11-C:");print(nonlinear_summary.to_string())
print("Original versus log1p skew:",profiles.mean_order_value.skew(),nonlinear.mean_order_value.skew())
print("Relationship comparison S11-D, log-transformed value before scaling:");print(nonlinear.corr().to_string())
distance_comparison=[]
for label,vector in distance_vectors.items():
    distance_comparison.append({"representation":label,"min":vector.min(),"median":np.median(vector),"p95":np.quantile(vector,.95),"max":vector.max(),"nearest_neighbour_changed_vs_z_percent":100*np.mean(nearest_neighbours[label]!=nearest_neighbours["z_score"])})
print("Pairwise distance summaries S11-E:");print(pd.DataFrame(distance_comparison).to_string(index=False))

# %% [markdown]
# 12. Task 3: recommendation table, boundaries and analysis-only features
# Recommend no nonlinear transformation followed by standardisation for each selected attribute in this sample. This intentionally retains interpretable absolute differences before putting the attributes on comparable variance scales. The nonlinear comparison is still performed and interpreted; a recommendation to keep a feature linear is permitted when evidenced.
# 
# Actual evidence: raw mean order value contributes about 99.9997% of average squared pairwise distance. Z-score scaling equalises marginal contributions at one third each. Min-max instead gives geography about 49.1%, so equal observed ranges do not mean equal variance influence. Log1p reduces value skew from about 0.928 to -0.592 and the maximum value z-score from 4.627 to 2.749, but increases the low-value extremeness from -2.183 to -4.059 and changes about 12.74% of nearest neighbours versus ordinary z-scores. Its maximum pairwise distance also increases, so reduced upper-tail skew is not uniformly improved geometry. Prefer the simpler linear spending feature for absolute spending comparisons; keep the log variant as sensitivity evidence, not a proven superior segmentation.
# 
# Order count remains a discrete, mildly right-skewed activity measure; an additional retained order has constant impact under linear standardisation. Distance has low negative skew and a geographic meaning in km; scaling, rather than a nonlinear operation, addresses unit mismatch. Standardised values lose their original units, so retain the baseline for interpretation. Valid extremes are preserved, not capped/deleted. Low pairwise correlations in the selected data reduce evidence of redundancy but do not prove independence or meaningful clusters. Equal marginal variance is an exploratory weighting choice, not business-validated importance. Sparse customer samples (including 66 single-order customers) can make averages unstable. Outlier removal and provisional cleansing affect these sample-only profiles.

# %%
recommendations=pd.DataFrame([
    {"attribute":"order_count","methods_compared":"Original; z-score; min-max","observed_effect_or_evidence":"S10/S11-A/B: range 1–10, skew 0.879; original activity contribution about 0.000103%","recommended_treatment":"Nonlinear: none; scaling: standardisation","justification_limitation":"Preserve equal extra-order increments while preventing AUD dominance. Discrete count; maximum remains about 4.32 SD."},
    {"attribute":"mean_order_value","methods_compared":"Original; z-score; min-max; log1p then z-score","observed_effect_or_evidence":"S11-B/C/E: original contribution 99.9997%; log skew 0.928 to -0.592; about 12.74% nearest-neighbour change","recommended_treatment":"Nonlinear: none; scaling: standardisation","justification_limitation":"Absolute spending-gap interpretation preferred. Log compresses upper tail but expands relative influence of low values; raw maximum remains about 4.63 SD."},
    {"attribute":"mean_delivery_distance","methods_compared":"Original; z-score; min-max","observed_effect_or_evidence":"S10/S11-A/B: skew -0.236; min-max distance contribution about 49.1% vs 33.3% under z-score","recommended_treatment":"Nonlinear: none; scaling: standardisation","justification_limitation":"Keep linear geographic differences but remove km/AUD scale mismatch. Great-circle distance, not actual delivery route."}
])
print(recommendations.to_string(index=False))
recommended_features=representations["z_score"].copy()
assert recommended_features.shape==(len(profiles),3)
assert profiles.index.equals(recommended_features.index)
assert all(df.columns.tolist()==SCHEMA for df in submitted.values())
for batch,path in output_paths.items():
    assert hashlib.sha256(path.read_bytes()).hexdigest()==hashlib.sha256(submitted[batch].to_csv(index=False).encode("utf-8")).hexdigest()
print("Profiles and transformed features retained in notebook only; cleaned CSVs not transformed.")
print("Computational checks:",validation.status.value_counts().to_dict())
print("Finalisation required: original frozen ZIP checksum, NLTK 3.9.2 strict-mode Run All, group verification/signatures and complete conversational-AI records/index.")
